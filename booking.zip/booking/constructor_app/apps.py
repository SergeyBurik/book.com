from django.apps import AppConfig


class ConstructorAppConfig(AppConfig):
    name = 'constructor_app'
    verbose_name = "Шаблоны"
