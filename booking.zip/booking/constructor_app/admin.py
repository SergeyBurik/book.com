from django.contrib import admin
from constructor_app.models import Template, WebSite

admin.site.register(Template)
admin.site.register(WebSite)
