import {createTagRepeat, optimizeTemplateHTML} from '../../lib/utils.js';

const daysTemplate = optimizeTemplateHTML(`<div class="days">
  <div class="days-of-week">${createTagRepeat('span', 7, {class: 'dow'})}</div>
  <div class="datepicker-grid">${createTagRepeat('span', 42)}</div>
</div>`);

export default daysTemplate;
