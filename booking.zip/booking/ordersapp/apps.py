from django.apps import AppConfig


class OrdersappConfig(AppConfig):
    name = 'ordersapp'
    verbose_name = 'Заказы'
